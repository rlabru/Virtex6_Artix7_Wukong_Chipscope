The following files were generated for 'coregen_vio' in directory
D:\Xilinx_prj\ChipScopePhy3\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * coregen_vio.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * coregen_vio.cdc
   * coregen_vio.constraints/coregen_vio.ucf
   * coregen_vio.constraints/coregen_vio.xdc
   * coregen_vio.ngc
   * coregen_vio.ucf
   * coregen_vio.vhd
   * coregen_vio.vho
   * coregen_vio.xdc
   * coregen_vio_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * coregen_vio.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * coregen_vio.gise
   * coregen_vio.xise

Deliver Readme:
   Readme file for the IP.

   * coregen_vio_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * coregen_vio_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

