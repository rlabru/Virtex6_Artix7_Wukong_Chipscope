The following files were generated for 'chipscope_icon' in directory
D:\Xilinx_prj\ChipScopePhy3\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_icon.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_icon.constraints/chipscope_icon.ucf
   * chipscope_icon.constraints/chipscope_icon.xdc
   * chipscope_icon.ngc
   * chipscope_icon.ucf
   * chipscope_icon.vhd
   * chipscope_icon.vho
   * chipscope_icon.xdc
   * chipscope_icon_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_icon.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * chipscope_icon.gise
   * chipscope_icon.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_icon_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_icon_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

