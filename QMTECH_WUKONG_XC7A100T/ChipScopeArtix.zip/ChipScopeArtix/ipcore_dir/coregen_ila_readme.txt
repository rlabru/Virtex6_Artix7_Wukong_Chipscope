The following files were generated for 'coregen_ila' in directory
D:\Xilinx_prj\ChipScopeArtix\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * coregen_ila.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * coregen_ila.cdc
   * coregen_ila.constraints/coregen_ila.ucf
   * coregen_ila.constraints/coregen_ila.xdc
   * coregen_ila.ncf
   * coregen_ila.ngc
   * coregen_ila.ucf
   * coregen_ila.vhd
   * coregen_ila.vho
   * coregen_ila.xdc
   * coregen_ila_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * coregen_ila.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * coregen_ila.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * coregen_ila.gise
   * coregen_ila.xise

Deliver Readme:
   Readme file for the IP.

   * coregen_ila_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * coregen_ila_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

